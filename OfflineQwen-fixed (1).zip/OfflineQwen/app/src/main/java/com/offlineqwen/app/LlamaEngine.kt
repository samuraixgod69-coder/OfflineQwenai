package com.offlineqwen.app

/**
 * Thin Kotlin wrapper around the native llama.cpp JNI bridge
 * (see app/src/main/cpp/llama-bridge.cpp).
 */
class LlamaEngine {

    companion object {
        init {
            System.loadLibrary("offlineqwen_llama")
        }
    }

    /** Called with UTF-8 bytes (always whole characters) per generated fragment.
     * Return false to stop generation early. */
    interface TokenCallback {
        fun onBytes(bytes: ByteArray): Boolean
    }

    private external fun nativeLoadModel(modelPath: String, nThreads: Int, nCtx: Int): Boolean
    private external fun nativeUnload()
    private external fun nativeResetContext()
    private external fun nativeStop()
    private external fun nativeGenerate(
        prompt: String,
        maxTokens: Int,
        temperature: Float,
        topP: Float,
        topK: Int,
        callback: TokenCallback
    )

    @Volatile
    var isLoaded = false
        private set

    fun load(modelPath: String, threads: Int = 4, contextSize: Int = 2048): Boolean {
        isLoaded = nativeLoadModel(modelPath, threads, contextSize)
        return isLoaded
    }

    fun unload() {
        if (isLoaded) {
            nativeUnload()
            isLoaded = false
        }
    }

    /** Asks a running generation to stop at the next token. */
    fun stop() {
        if (isLoaded) nativeStop()
    }

    fun resetConversation() {
        if (isLoaded) nativeResetContext()
    }

    /** Streams generated text; [onToken] is called for each piece and should return
     * true to keep generating, false to stop early. */
    fun generate(
        prompt: String,
        maxTokens: Int,
        temperature: Float,
        topP: Float,
        topK: Int,
        onToken: (String) -> Boolean
    ) {
        if (!isLoaded) return
        nativeGenerate(prompt, maxTokens, temperature, topP, topK, object : TokenCallback {
            override fun onBytes(bytes: ByteArray): Boolean = onToken(String(bytes, Charsets.UTF_8))
        })
    }
}
