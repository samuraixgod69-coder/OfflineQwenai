package com.offlineqwen.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.offlineqwen.app.GenerationSettings

@Composable
fun SettingsDialog(
    current: GenerationSettings,
    onDismiss: () -> Unit,
    onSave: (GenerationSettings) -> Unit
) {
    var temperature by remember { mutableStateOf(current.temperature) }
    var topP by remember { mutableStateOf(current.topP) }
    var topK by remember { mutableStateOf(current.topK.toString()) }
    var maxTokens by remember { mutableStateOf(current.maxTokens.toString()) }
    var contextSize by remember { mutableStateOf(current.contextSize.toString()) }
    var threads by remember { mutableStateOf(current.threads.toString()) }
    var systemPrompt by remember { mutableStateOf(current.systemPrompt) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Settings") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("Temperature: ${"%.2f".format(temperature)}")
                Slider(value = temperature, onValueChange = { temperature = it }, valueRange = 0.1f..1.5f)

                Text("Top-P: ${"%.2f".format(topP)}")
                Slider(value = topP, onValueChange = { topP = it }, valueRange = 0.1f..1.0f)

                OutlinedTextField(value = topK, onValueChange = { topK = it }, label = { Text("Top-K") })
                OutlinedTextField(value = maxTokens, onValueChange = { maxTokens = it }, label = { Text("Max tokens per reply") })
                OutlinedTextField(value = contextSize, onValueChange = { contextSize = it }, label = { Text("Context size (reloads model)") })
                OutlinedTextField(value = threads, onValueChange = { threads = it }, label = { Text("CPU threads (reloads model)") })
                OutlinedTextField(
                    value = systemPrompt,
                    onValueChange = { systemPrompt = it },
                    label = { Text("System prompt") },
                    minLines = 3
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onSave(
                    GenerationSettings(
                        temperature = temperature,
                        topP = topP,
                        topK = topK.toIntOrNull() ?: current.topK,
                        maxTokens = maxTokens.toIntOrNull() ?: current.maxTokens,
                        contextSize = contextSize.toIntOrNull() ?: current.contextSize,
                        threads = threads.toIntOrNull() ?: current.threads,
                        systemPrompt = systemPrompt
                    )
                )
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
