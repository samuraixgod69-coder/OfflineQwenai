package com.offlineqwen.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class ChatMessage(
    val text: String,
    val isUser: Boolean,
    val timestamp: Long = System.currentTimeMillis()
)

/** Stores the chat transcript as a small JSON file in app-private storage -
 * no database dependency needed for a single ongoing conversation. */
class ChatHistoryStore(private val context: Context) {

    private fun historyFile(): File = File(context.filesDir, "chat_history.json")

    fun save(messages: List<ChatMessage>) {
        val arr = JSONArray()
        for (m in messages) {
            arr.put(JSONObject().apply {
                put("text", m.text)
                put("isUser", m.isUser)
                put("timestamp", m.timestamp)
            })
        }
        historyFile().writeText(arr.toString())
    }

    fun load(): List<ChatMessage> {
        val file = historyFile()
        if (!file.exists()) return emptyList()
        return try {
            val arr = JSONArray(file.readText())
            (0 until arr.length()).map { i ->
                val obj = arr.getJSONObject(i)
                ChatMessage(
                    text = obj.getString("text"),
                    isUser = obj.getBoolean("isUser"),
                    timestamp = obj.optLong("timestamp", 0L)
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun clear() {
        historyFile().delete()
    }
}
