package com.offlineqwen.app

import android.content.Context
import android.net.Uri
import java.io.File

/** Copies a user-picked .gguf file into the app's private storage so it survives
 * across launches and doesn't depend on the original file/URI staying available. */
class ModelManager(private val context: Context) {

    fun modelDir(): File = File(context.filesDir, "models").apply { mkdirs() }

    fun currentModelFile(): File? =
        modelDir().listFiles()?.firstOrNull { it.name.endsWith(".gguf") }

    fun importFromUri(uri: Uri, displayName: String, onProgress: (Int) -> Unit = {}): File {
        // Clear any previous model file - we support one active model at a time.
        modelDir().listFiles()?.forEach { it.delete() }

        val safeName = if (displayName.endsWith(".gguf")) displayName else "$displayName.gguf"
        val dest = File(modelDir(), safeName)

        val totalBytes = try {
            context.contentResolver.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: -1L
        } catch (e: Exception) {
            -1L
        }

        context.contentResolver.openInputStream(uri)?.use { input ->
            dest.outputStream().use { output ->
                val buffer = ByteArray(1 shl 20) // 1 MB chunks
                var copied = 0L
                var read: Int
                while (input.read(buffer).also { read = it } != -1) {
                    output.write(buffer, 0, read)
                    copied += read
                    if (totalBytes > 0) {
                        onProgress(((copied * 100) / totalBytes).toInt())
                    }
                }
            }
        }
        return dest
    }

    fun deleteModel() {
        modelDir().listFiles()?.forEach { it.delete() }
    }
}
