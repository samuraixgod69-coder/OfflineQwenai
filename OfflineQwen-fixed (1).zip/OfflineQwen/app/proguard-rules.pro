# Keep native bridge class and its JNI-called methods
-keep class com.offlineqwen.app.LlamaEngine { *; }
-keep class com.offlineqwen.app.LlamaEngine$TokenCallback { *; }
