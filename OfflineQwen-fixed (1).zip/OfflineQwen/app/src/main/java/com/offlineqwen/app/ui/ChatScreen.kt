package com.offlineqwen.app.ui

import android.app.Activity
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.offlineqwen.app.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(viewModel: ChatViewModel) {
    val uiState by viewModel.uiState.collectAsState()
    val settings by viewModel.settings.collectAsState()
    val context = LocalContext.current
    var input by remember { mutableStateOf("") }
    var showSettings by remember { mutableStateOf(false) }
    var showMenu by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()

    val modelPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri?.let {
            runCatching {
                context.contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            val name = it.lastPathSegment?.substringAfterLast('/') ?: "model.gguf"
            viewModel.importModel(it, name)
        }
    }

    val voiceLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            VoiceInputHelper.extractText(result.data)?.let { text ->
                input = if (input.isBlank()) text else "$input $text"
            }
        }
    }

    LaunchedEffect(uiState.messages.size) {
        if (uiState.messages.isNotEmpty()) {
            listState.animateScrollToItem(uiState.messages.size - 1)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(uiState.modelFileName ?: "Offline Qwen") },
                actions = {
                    IconButton(onClick = { showMenu = true }) {
                        Icon(Icons.Default.MoreVert, contentDescription = "Menu")
                    }
                    DropdownMenu(expanded = showMenu, onDismissRequest = { showMenu = false }) {
                        DropdownMenuItem(text = { Text("New chat") }, onClick = {
                            showMenu = false
                            viewModel.newChat()
                        })
                        DropdownMenuItem(text = { Text("Export PDF") }, onClick = {
                            showMenu = false
                            if (uiState.messages.isNotEmpty()) {
                                val uri = PdfExporter.export(context, uiState.messages)
                                context.startActivity(Intent.createChooser(PdfExporter.shareIntent(uri), "Share chat PDF"))
                            }
                        })
                        DropdownMenuItem(text = { Text("Settings") }, onClick = {
                            showMenu = false
                            showSettings = true
                        })
                        DropdownMenuItem(text = { Text("Change model") }, onClick = {
                            showMenu = false
                            modelPicker.launch(arrayOf("*/*"))
                        })
                        DropdownMenuItem(text = { Text("Delete model") }, onClick = {
                            showMenu = false
                            viewModel.deleteModel()
                        })
                    }
                }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxSize()) {

            when (uiState.loadState) {
                LoadState.NOT_LOADED -> ModelSetupPanel(onPick = { modelPicker.launch(arrayOf("*/*")) })
                LoadState.LOADING -> Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator()
                        Spacer(Modifier.height(8.dp))
                        Text("Loading model into RAM…")
                    }
                }
                LoadState.ERROR -> Text(
                    uiState.errorMessage ?: "Error loading model",
                    color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.padding(16.dp)
                )
                LoadState.READY -> {}
            }

            LazyColumn(
                state = listState,
                modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(uiState.messages) { msg -> MessageBubble(msg) }
            }

            Row(
                modifier = Modifier.fillMaxWidth().padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { voiceLauncher.launch(VoiceInputHelper.createIntent()) }) {
                    Icon(Icons.Default.Mic, contentDescription = "Voice input")
                }
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Type a message…") },
                    enabled = uiState.loadState == LoadState.READY && !uiState.isGenerating
                )
                if (uiState.isGenerating) {
                    IconButton(onClick = { viewModel.stopGenerating() }) {
                        Icon(Icons.Default.Stop, contentDescription = "Stop")
                    }
                } else {
                    IconButton(
                        onClick = {
                            val text = input
                            input = ""
                            viewModel.sendMessage(text)
                        },
                        enabled = uiState.loadState == LoadState.READY && input.isNotBlank()
                    ) {
                        Icon(Icons.Default.Send, contentDescription = "Send")
                    }
                }
            }
        }
    }

    if (showSettings) {
        SettingsDialog(
            current = settings,
            onDismiss = { showSettings = false },
            onSave = {
                viewModel.updateSettings(it)
                showSettings = false
            }
        )
    }
}

@Composable
private fun ModelSetupPanel(onPick: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxWidth().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("No model loaded", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        Text(
            "Pick a .gguf model file from your phone storage " +
                "(e.g. Qwen3-1.7B-Q4_K_M.gguf, downloaded separately via a browser).",
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(16.dp))
        Button(onClick = onPick) { Text("Pick model file (.gguf)") }
    }
}

@Composable
private fun MessageBubble(msg: ChatMessage) {
    val bg = if (msg.isUser) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (msg.isUser) Arrangement.End else Arrangement.Start
    ) {
        Surface(color = bg, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth(0.85f)) {
            Text(text = msg.text.ifBlank { "…" }, modifier = Modifier.padding(10.dp))
        }
    }
}
