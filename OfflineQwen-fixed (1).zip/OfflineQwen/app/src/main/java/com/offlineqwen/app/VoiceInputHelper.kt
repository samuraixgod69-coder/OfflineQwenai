package com.offlineqwen.app

import android.content.Intent
import android.speech.RecognizerIntent
import java.util.Locale

/** Uses Android's built-in speech recognizer activity. Whether this runs fully
 * offline depends on the device's installed speech-service / downloaded
 * offline language pack - that's an OS-level setting, not something an app
 * can force. */
object VoiceInputHelper {

    fun createIntent(): Intent =
        Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak now…")
        }

    fun extractText(data: Intent?): String? =
        data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
}
