package com.offlineqwen.app

import android.content.Context
import android.content.Intent
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Renders the chat transcript as a simple A4 PDF entirely on-device, with no
 * third-party PDF library - just Android's built-in PdfDocument + Canvas. */
object PdfExporter {

    private const val PAGE_WIDTH = 595
    private const val PAGE_HEIGHT = 842
    private const val MARGIN = 40f
    private const val LINE_HEIGHT = 18f

    fun export(context: Context, messages: List<ChatMessage>): Uri {
        val titlePaint = Paint().apply { textSize = 14f; isFakeBoldText = true }
        val bodyPaint = Paint().apply { textSize = 12f }

        val document = PdfDocument()
        var pageNumber = 1
        var page = document.startPage(PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, pageNumber).create())
        var canvas = page.canvas
        var y = MARGIN

        fun newPageIfNeeded(linesNeeded: Int = 1) {
            if (y + linesNeeded * LINE_HEIGHT > PAGE_HEIGHT - MARGIN) {
                document.finishPage(page)
                pageNumber++
                page = document.startPage(PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, pageNumber).create())
                canvas = page.canvas
                y = MARGIN
            }
        }

        for (msg in messages) {
            if (msg.text.isBlank()) continue
            val who = if (msg.isUser) "You" else "Assistant"
            newPageIfNeeded(2)
            canvas.drawText("$who:", MARGIN, y, titlePaint)
            y += LINE_HEIGHT

            val maxWidth = PAGE_WIDTH - MARGIN * 2
            var line = StringBuilder()
            for (word in msg.text.split(" ")) {
                val trial = if (line.isEmpty()) word else "$line $word"
                if (bodyPaint.measureText(trial) > maxWidth) {
                    newPageIfNeeded()
                    canvas.drawText(line.toString(), MARGIN, y, bodyPaint)
                    y += LINE_HEIGHT
                    line = StringBuilder(word)
                } else {
                    line = StringBuilder(trial)
                }
            }
            if (line.isNotEmpty()) {
                newPageIfNeeded()
                canvas.drawText(line.toString(), MARGIN, y, bodyPaint)
                y += LINE_HEIGHT
            }
            y += LINE_HEIGHT / 2
        }

        document.finishPage(page)

        val exportDir = File(context.getExternalFilesDir(null), "exports").apply { mkdirs() }
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val file = File(exportDir, "chat_$stamp.pdf")
        FileOutputStream(file).use { document.writeTo(it) }
        document.close()

        return FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    }

    fun shareIntent(uri: Uri): Intent =
        Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
}
