package com.offlineqwen.app

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class LoadState { NOT_LOADED, LOADING, READY, ERROR }

data class ChatUiState(
    val messages: List<ChatMessage> = emptyList(),
    val loadState: LoadState = LoadState.NOT_LOADED,
    val isGenerating: Boolean = false,
    val errorMessage: String? = null,
    val modelFileName: String? = null
)

data class GenerationSettings(
    val temperature: Float = 0.7f,
    val topP: Float = 0.9f,
    val topK: Int = 40,
    val maxTokens: Int = 512,
    val contextSize: Int = 2048,
    val threads: Int = 4,
    val systemPrompt: String = "You are a helpful offline assistant running entirely on this device."
)

class ChatViewModel(application: Application) : AndroidViewModel(application) {

    private val engine = LlamaEngine()
    private val modelManager = ModelManager(application)
    private val historyStore = ChatHistoryStore(application)
    private val prefs = application.getSharedPreferences("offlineqwen_settings", 0)

    private val _uiState = MutableStateFlow(ChatUiState())
    val uiState: StateFlow<ChatUiState> = _uiState

    private val _settings = MutableStateFlow(loadSettings())
    val settings: StateFlow<GenerationSettings> = _settings

    init {
        _uiState.update { it.copy(messages = historyStore.load()) }
        modelManager.currentModelFile()?.let { file ->
            _uiState.update { it.copy(modelFileName = file.name) }
            loadModel(file.absolutePath)
        }
    }

    private fun loadSettings() = GenerationSettings(
        temperature = prefs.getFloat("temperature", 0.7f),
        topP = prefs.getFloat("topP", 0.9f),
        topK = prefs.getInt("topK", 40),
        maxTokens = prefs.getInt("maxTokens", 512),
        contextSize = prefs.getInt("contextSize", 2048),
        threads = prefs.getInt("threads", 4),
        systemPrompt = prefs.getString("systemPrompt", null)
            ?: "You are a helpful offline assistant running entirely on this device."
    )

    fun updateSettings(newSettings: GenerationSettings) {
        val old = _settings.value
        _settings.value = newSettings
        prefs.edit()
            .putFloat("temperature", newSettings.temperature)
            .putFloat("topP", newSettings.topP)
            .putInt("topK", newSettings.topK)
            .putInt("maxTokens", newSettings.maxTokens)
            .putInt("contextSize", newSettings.contextSize)
            .putInt("threads", newSettings.threads)
            .putString("systemPrompt", newSettings.systemPrompt)
            .apply()

        // Threads/context size only take effect on (re)load.
        val needsReload = old.contextSize != newSettings.contextSize || old.threads != newSettings.threads
        if (needsReload && _uiState.value.loadState == LoadState.READY) {
            modelManager.currentModelFile()?.let { loadModel(it.absolutePath) }
        }
    }

    fun importModel(uri: Uri, displayName: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(loadState = LoadState.LOADING, errorMessage = null) }
            val file = withContext(Dispatchers.IO) {
                modelManager.importFromUri(uri, displayName)
            }
            _uiState.update { it.copy(modelFileName = file.name) }
            loadModel(file.absolutePath)
        }
    }

    private fun loadModel(path: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(loadState = LoadState.LOADING, errorMessage = null) }
            val ok = withContext(Dispatchers.Default) {
                engine.load(path, threads = _settings.value.threads, contextSize = _settings.value.contextSize)
            }
            _uiState.update {
                it.copy(
                    loadState = if (ok) LoadState.READY else LoadState.ERROR,
                    errorMessage = if (ok) null else "Model load failed. Check free RAM and that the file is a valid .gguf."
                )
            }
        }
    }

    fun sendMessage(text: String) {
        if (text.isBlank() || _uiState.value.isGenerating || _uiState.value.loadState != LoadState.READY) return

        val userMsg = ChatMessage(text, isUser = true)
        val assistantMsg = ChatMessage("", isUser = false)
        _uiState.update { it.copy(messages = it.messages + userMsg + assistantMsg, isGenerating = true) }

        viewModelScope.launch {
            val prompt = buildPrompt()
            val builder = StringBuilder()

            withContext(Dispatchers.Default) {
                engine.generate(
                    prompt = prompt,
                    maxTokens = _settings.value.maxTokens,
                    temperature = _settings.value.temperature,
                    topP = _settings.value.topP,
                    topK = _settings.value.topK
                ) { piece ->
                    builder.append(piece)
                    _uiState.update { state ->
                        val updated = state.messages.toMutableList()
                        if (updated.isNotEmpty()) {
                            updated[updated.lastIndex] = updated.last().copy(text = builder.toString())
                        }
                        state.copy(messages = updated)
                    }
                    true
                }
            }

            _uiState.update { it.copy(isGenerating = false) }
            historyStore.save(_uiState.value.messages)
        }
    }

    // Qwen's chat template uses ChatML-style turn markers.
    private fun buildPrompt(): String {
        val sb = StringBuilder()
        sb.append("<|im_start|>system\n").append(_settings.value.systemPrompt).append("<|im_end|>\n")
        for (msg in _uiState.value.messages) {
            if (msg.text.isBlank()) continue
            val role = if (msg.isUser) "user" else "assistant"
            sb.append("<|im_start|>").append(role).append("\n").append(msg.text).append("<|im_end|>\n")
        }
        sb.append("<|im_start|>assistant\n")
        return sb.toString()
    }

    fun stopGenerating() = engine.stop()

    fun newChat() {
        engine.resetConversation()
        historyStore.clear()
        _uiState.update { it.copy(messages = emptyList()) }
    }

    fun deleteModel() {
        engine.unload()
        modelManager.deleteModel()
        _uiState.update { it.copy(modelFileName = null, loadState = LoadState.NOT_LOADED) }
    }

    override fun onCleared() {
        engine.unload()
        super.onCleared()
    }
}
