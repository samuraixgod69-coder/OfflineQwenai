// JNI bridge between Kotlin (LlamaEngine.kt) and llama.cpp's C API.
// Loads a GGUF model fully offline, runs CPU-only inference (n_gpu_layers = 0,
// safest default on a 4GB-RAM phone), and streams generated text back to
// Kotlin one piece at a time through a callback object.

#include <jni.h>
#include <string>
#include <vector>
#include <mutex>
#include <algorithm>
#include <android/log.h>
#include "llama.h"

#define LOG_TAG "OfflineQwenNative"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

static llama_model* g_model = nullptr;
static llama_context* g_ctx = nullptr;
static const llama_vocab* g_vocab = nullptr;
static bool g_backend_initialized = false;
// Serializes load/unload/reset/generate so a model is never freed mid-decode.
static std::mutex g_mutex;
// Set by Kotlin to abort a running generation.
static volatile bool g_stop = false;

extern "C" JNIEXPORT jboolean JNICALL
Java_com_offlineqwen_app_LlamaEngine_nativeLoadModel(
        JNIEnv* env, jobject /*thiz*/, jstring modelPath, jint nThreads, jint nCtx) {
    std::lock_guard<std::mutex> lock(g_mutex);

    // Unload any previous model first.
    if (g_ctx) { llama_free(g_ctx); g_ctx = nullptr; }
    if (g_model) { llama_model_free(g_model); g_model = nullptr; }

    if (!g_backend_initialized) {
        llama_backend_init();
        g_backend_initialized = true;
    }

    const char* path = env->GetStringUTFChars(modelPath, nullptr);

    llama_model_params mparams = llama_model_default_params();
    mparams.n_gpu_layers = 0; // CPU only - safest on a 4GB-RAM phone

    g_model = llama_model_load_from_file(path, mparams);
    env->ReleaseStringUTFChars(modelPath, path);

    if (!g_model) {
        LOGE("Failed to load model file");
        return JNI_FALSE;
    }

    g_vocab = llama_model_get_vocab(g_model);

    llama_context_params cparams = llama_context_default_params();
    cparams.n_ctx = nCtx > 0 ? (uint32_t) nCtx : 2048u;
    cparams.n_threads = nThreads > 0 ? nThreads : 4;
    cparams.n_threads_batch = cparams.n_threads;
    cparams.n_batch = std::min<uint32_t>(cparams.n_ctx, 512);
    cparams.n_ubatch = std::min<uint32_t>(cparams.n_batch, 512);

    g_ctx = llama_init_from_model(g_model, cparams);
    if (!g_ctx) {
        LOGE("Failed to create context");
        llama_model_free(g_model);
        g_model = nullptr;
        return JNI_FALSE;
    }

    LOGI("Model loaded OK (ctx=%d, threads=%d)", cparams.n_ctx, cparams.n_threads);
    return JNI_TRUE;
}

extern "C" JNIEXPORT void JNICALL
Java_com_offlineqwen_app_LlamaEngine_nativeUnload(JNIEnv*, jobject) {
    g_stop = true;
    std::lock_guard<std::mutex> lock(g_mutex);
    if (g_ctx) { llama_free(g_ctx); g_ctx = nullptr; }
    if (g_model) { llama_model_free(g_model); g_model = nullptr; }
    g_vocab = nullptr;
}

extern "C" JNIEXPORT void JNICALL
Java_com_offlineqwen_app_LlamaEngine_nativeResetContext(JNIEnv*, jobject) {
    g_stop = true;
    std::lock_guard<std::mutex> lock(g_mutex);
    if (g_ctx) {
        llama_memory_clear(llama_get_memory(g_ctx), true);
    }
}

extern "C" JNIEXPORT void JNICALL
Java_com_offlineqwen_app_LlamaEngine_nativeStop(JNIEnv*, jobject) {
    g_stop = true;
}

// Length of the longest prefix of [data, data+len) that ends on a complete
// UTF-8 character. A token can end in the middle of a multi-byte character
// (emoji, Hindi, CJK...); those bytes must wait for the next token.
static size_t utf8_complete_prefix(const std::string& s) {
    size_t len = s.size();
    size_t i = len;
    int back = 0;
    while (i > 0 && back < 4) {
        unsigned char c = (unsigned char) s[i - 1];
        if ((c & 0xC0) == 0x80) { i--; back++; continue; }  // continuation byte
        int need = (c >= 0xF0) ? 4 : (c >= 0xE0) ? 3 : (c >= 0xC0) ? 2 : 1;
        int have = (int) (len - (i - 1));
        return have >= need ? len : i - 1;
    }
    return len;
}

static bool emit(JNIEnv* env, jobject callback, jmethodID onBytes, const std::string& bytes) {
    jbyteArray arr = env->NewByteArray((jsize) bytes.size());
    env->SetByteArrayRegion(arr, 0, (jsize) bytes.size(), (const jbyte*) bytes.data());
    jboolean keep = env->CallBooleanMethod(callback, onBytes, arr);
    env->DeleteLocalRef(arr);
    return keep == JNI_TRUE && !env->ExceptionCheck();
}

extern "C" JNIEXPORT void JNICALL
Java_com_offlineqwen_app_LlamaEngine_nativeGenerate(
        JNIEnv* env, jobject /*thiz*/, jstring prompt,
        jint maxTokens, jfloat temperature, jfloat topP, jint topK,
        jobject callback) {

    std::lock_guard<std::mutex> lock(g_mutex);
    g_stop = false;

    if (!g_ctx || !g_model || !g_vocab) {
        LOGE("nativeGenerate called before a model was loaded");
        return;
    }

    jclass cbClass = env->GetObjectClass(callback);
    jmethodID onBytes = env->GetMethodID(cbClass, "onBytes", "([B)Z");
    if (!onBytes) return;

    const char* promptChars = env->GetStringUTFChars(prompt, nullptr);
    std::string promptStr(promptChars);
    env->ReleaseStringUTFChars(prompt, promptChars);

    // The Kotlin side re-sends the whole conversation every turn, so start
    // from an empty KV cache; otherwise history would be decoded twice.
    llama_memory_clear(llama_get_memory(g_ctx), true);

    // First call with a null buffer returns the negative token count needed.
    int nPromptTokens = -llama_tokenize(
            g_vocab, promptStr.c_str(), (int32_t) promptStr.size(),
            nullptr, 0, true, true);
    if (nPromptTokens <= 0) {
        LOGE("Tokenization failed");
        return;
    }

    std::vector<llama_token> tokens(nPromptTokens);
    if (llama_tokenize(
            g_vocab, promptStr.c_str(), (int32_t) promptStr.size(),
            tokens.data(), (int32_t) tokens.size(), true, true) < 0) {
        LOGE("Tokenization failed (2nd pass)");
        return;
    }

    const int nCtx = (int) llama_n_ctx(g_ctx);
    if (nPromptTokens >= nCtx - 8) {
        LOGE("Prompt (%d tokens) does not fit in context (%d)", nPromptTokens, nCtx);
        std::string msg = "[Conversation too long for the context size - start a New chat or raise Context size in Settings.]";
        emit(env, callback, onBytes, msg);
        return;
    }
    // Never generate past the end of the context window.
    const int budget = std::min<int>(maxTokens, nCtx - nPromptTokens - 1);

    llama_sampler* sampler = llama_sampler_chain_init(llama_sampler_chain_default_params());
    llama_sampler_chain_add(sampler, llama_sampler_init_top_k(topK > 0 ? topK : 40));
    llama_sampler_chain_add(sampler, llama_sampler_init_top_p(topP > 0.0f ? topP : 0.9f, 1));
    llama_sampler_chain_add(sampler, llama_sampler_init_temp(temperature > 0.0f ? temperature : 0.7f));
    llama_sampler_chain_add(sampler, llama_sampler_init_dist(LLAMA_DEFAULT_SEED));

    // Prefill in chunks of at most n_batch tokens (llama_decode aborts on more).
    const int nBatch = (int) llama_n_batch(g_ctx);
    bool ok = true;
    for (int i = 0; i < nPromptTokens && ok; i += nBatch) {
        if (g_stop) { ok = false; break; }
        int n = std::min(nBatch, nPromptTokens - i);
        llama_batch b = llama_batch_get_one(tokens.data() + i, n);
        if (llama_decode(g_ctx, b) != 0) {
            LOGE("llama_decode failed during prefill");
            ok = false;
        }
    }

    std::string pending;
    llama_token newToken = 0;
    int generated = 0;
    while (ok && generated < budget && !g_stop) {
        newToken = llama_sampler_sample(sampler, g_ctx, -1);
        if (llama_vocab_is_eog(g_vocab, newToken)) break;
        llama_sampler_accept(sampler, newToken);

        char buf[256];
        int n = llama_token_to_piece(g_vocab, newToken, buf, sizeof(buf), 0, true);
        if (n > 0) pending.append(buf, n);

        size_t cut = utf8_complete_prefix(pending);
        if (cut > 0) {
            if (!emit(env, callback, onBytes, pending.substr(0, cut))) { pending.clear(); break; }
            pending.erase(0, cut);
        }
        generated++;

        llama_batch b = llama_batch_get_one(&newToken, 1);
        if (llama_decode(g_ctx, b) != 0) {
            LOGE("llama_decode failed");
            break;
        }
    }

    llama_sampler_free(sampler);
}
